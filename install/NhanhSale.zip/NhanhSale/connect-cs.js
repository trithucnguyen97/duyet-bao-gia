// Nhanh vn Đại Dương (Sale) — chạy riêng trên trang "đã cấp mã kết nối" của Bảng giá.
// Chỉ đọc mã kết nối phạm vi "bảng giá khách" (#bgx-ext-token-customer, chỉ có trong DOM, không có trên URL),
// gửi cho background rồi xóa khỏi trang. Mã kết nối đầy đủ dành cho extension khác trên cùng trang KHÔNG được đụng tới.
(function () {
  var el = document.getElementById('bgx-ext-token-customer');
  if (!el) return;
  var token = el.getAttribute('data-token') || '', user = el.getAttribute('data-user') || '';
  el.removeAttribute('data-token');
  chrome.runtime.sendMessage({ type: 'nhs:bgToken', token: token, user: user }, function (res) {
    void chrome.runtime.lastError;
    if (res && res.ok) {
      el.remove();
      document.dispatchEvent(new CustomEvent('bgx-ext-received'));
      setTimeout(function () { try { window.close(); } catch (e) {} }, 2500);
    }
  });
})();
