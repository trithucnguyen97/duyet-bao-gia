// Nhanh vn Đại Dương (Sale) — PHẦN VỎ (service worker), cài 1 lần trên mỗi máy.
// Tự cập nhật "phần ruột" (src/content.js) từ GitHub (kho công khai trithucnguyen97/duyet-bao-gia, thư mục sale/):
// đọc version.json, kiểm SHA-256 + chữ ký ECDSA, lưu vào chrome.storage.local và chạy trên nhanh.vn bằng chrome.userScripts.
// Bản cho Sale: chỉ đọc bảng giá BÁN của từng khách trên Bảng giá, bằng mã kết nối riêng từng người (phạm vi "customer":
// máy chủ không bao giờ trả bảng giá chung cho mã này, và chỉ trả khách do chính người đó tạo / được gán phụ trách).
// tools/release.mjs chặn nếu có thứ khác lọt vào.
// Máy phát triển: tự reload khi sửa phần vỏ, tự nạp bản build mới ở payload-dist/.
var MATCHES = ['https://nhanh.vn/*'];
var SHELL_VERSION = chrome.runtime.getManifest().version;
var IS_DEV = !('update_url' in chrome.runtime.getManifest());

var BG_BASE = 'https://banggia.baobidaiduong.com';
var BG_PRICES_URL = BG_BASE + '/products/api-prices';
var BG_APP = 'Nhanh.vn Sale';
var BG_TOKEN_RE = /^bgx_[a-f0-9]{48}$/;
// Số từ đây trở lên là SĐT (bỏ số 0 đầu) chứ không phải id khách — cùng quy ước với máy chủ
var BG_PHONE_AS_ID_MIN = 100000000;

// ---------------------------------------------------------------------------
// TIN NHẮN: popup / phần vỏ trên trang (onMessage), phần ruột (onUserScriptMessage)
// ---------------------------------------------------------------------------
// Phần ruột CHỈ được hỏi 2 việc: SĐT này là khách nào, và bảng giá bán của khách đó. Mọi lệnh khác chỉ dành cho phần vỏ.
function payloadRoute(request, sender, sendResponse) {
    if (!request) return;
    if (request.action === 'nhs:khByPhone') { khByPhone(request.phone).then(sendResponse); return true; }
    if (request.action === 'nhs:khPrices') { khPrices(request.customerId).then(sendResponse); return true; }
}
function route(request, sender, sendResponse) {
    if (!request) return;
    if (request.action) return payloadRoute(request, sender, sendResponse);
    if (request.type === 'nhs:bgStatus') { bgStatus().then(sendResponse); return true; }
    if (request.type === 'nhs:bgConnect') { chrome.tabs.create({ url: BG_BASE + '/ext-connect?app=' + encodeURIComponent(BG_APP) + '&scope=customer' }); return; }
    if (request.type === 'nhs:bgLogout') { bgLogout().then(sendResponse); return true; }
    if (request.type === 'nhs:bgToken') {
        // Chỉ nhận từ content script của chính extension trên đúng trang cấp mã kết nối của Bảng giá
        var url = (sender && sender.tab && sender.tab.url) || '';
        if (!sender || sender.id !== chrome.runtime.id || url.indexOf(BG_BASE + '/ext-connect/done') !== 0 || !BG_TOKEN_RE.test(request.token || '')) { sendResponse({ ok: false }); return; }
        chrome.storage.local.set({ bgToken: request.token, bgUser: String(request.user || '').slice(0, 100), bgAt: Date.now() }).then(function () {
            return chrome.storage.local.remove('bgExpired');
        }).then(function () {
            sendResponse({ ok: true });
            notifyBg();
        });
        return true;
    }
    if (request.type === 'nhs:checkUpdate') {
        checkUpdate({ throttle: !request.force }).then(sendResponse, function (e) { status().then(function (st) { st.lastError = String(e && e.message || e); sendResponse(st); }); });
        return true;
    }
    if (request.type === 'nhs:status') { status().then(sendResponse); return true; }
    if (request.type === 'nhs:openExtSettings') { chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); return; }
    if (request.type === 'nhs:devcheck') { devCheck().then(sendResponse, function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }); return true; }
}
chrome.runtime.onMessage.addListener(route);
if (chrome.runtime.onUserScriptMessage) chrome.runtime.onUserScriptMessage.addListener(payloadRoute);
// Cho phần ruột (USER_SCRIPT) gửi tin về đây
function allowPayloadMessaging() {
    try { return chrome.userScripts.configureWorld({ messaging: true }).catch(function () {}); } catch (e) { return Promise.resolve(); }
}
allowPayloadMessaging();

// ---------------------------------------------------------------------------
// BẢNG GIÁ THEO KHÁCH
// ---------------------------------------------------------------------------
async function bgStatus() {
    var g = await chrome.storage.local.get(['bgToken', 'bgUser', 'bgAt', 'bgExpired']);
    return { connected: !!g.bgToken, user: g.bgUser || '', at: g.bgAt || 0, expired: !!g.bgExpired };
}
function notifyBg() {
    chrome.tabs.query({ url: MATCHES }).then(function (tabs) {
        tabs.forEach(function (t) { chrome.tabs.sendMessage(t.id, { type: 'nhs:bgChanged' }).catch(function () {}); });
    });
}
async function bgLogout() {
    var t = (await chrome.storage.local.get('bgToken')).bgToken || '';
    if (t) { try { await fetch(BG_BASE + '/ext-connect/api-logout', { method: 'POST', headers: { 'X-Api-Token': t } }); } catch (e) {} }
    await chrome.storage.local.remove(['bgToken', 'bgUser', 'bgAt', 'bgExpired']);
    notifyBg();
    return { ok: true };
}
// Mọi lần gọi API giá đều kèm customer_id (id khách, hoặc SĐT bỏ số 0 đầu). Không có đường nào gọi bảng giá chung.
// 401 = mã kết nối bị thu hồi / tài khoản bị khóa -> xóa, nhắc kết nối lại. 403 = không phải khách của mình.
async function khGet(n) {
    if (!Number.isSafeInteger(n) || n <= 0) return { ok: false, error: 'BAD_REQUEST' };
    var token = (await chrome.storage.local.get('bgToken')).bgToken || '';
    if (!token) return { ok: false, error: 'NOT_CONNECTED' };
    try {
        var r = await fetch(BG_PRICES_URL + '?customer_id=' + n, { headers: { 'X-Api-Token': token }, cache: 'no-store' });
        if (r.status === 401) {
            await chrome.storage.local.remove(['bgToken', 'bgAt']);
            await chrome.storage.local.set({ bgExpired: true });
            notifyBg();
            return { ok: false, error: 'NOT_CONNECTED' };
        }
        if (r.status === 403) return { ok: false, error: 'FORBIDDEN' };
        if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
        return { ok: true, data: await r.json() };
    } catch (e) {
        return { ok: false, error: 'NETWORK' };
    }
}
async function khByPhone(phone) {
    phone = String(phone || '');
    if (!/^0[1-9]\d{8,9}$/.test(phone)) return { ok: false, error: 'BAD_REQUEST' };
    var res = await khGet(Number(phone.slice(1)));
    if (!res.ok) return res;
    var c = res.data && res.data.__customer;
    if (!c || !Number.isInteger(c.id) || c.id <= 0) return { ok: true, customer: null };
    return { ok: true, customer: { id: c.id, name: String(c.name || ''), url: BG_BASE + '/prices/' + c.id + (c.hash ? '#' + encodeURIComponent(String(c.hash)) : '') } };
}
async function khPrices(customerId) {
    var id = Number(customerId);
    if (!Number.isInteger(id) || id <= 0 || id >= BG_PHONE_AS_ID_MIN) return { ok: false, error: 'BAD_REQUEST' };
    var res = await khGet(id);
    if (!res.ok) return res;
    var prices = {};
    Object.keys(res.data || {}).forEach(function (k) {
        var v = res.data[k];
        if (k.indexOf('__') !== 0 && typeof v === 'number' && v > 0) prices[k] = v;
    });
    return { ok: true, prices: prices };
}

// ---------------------------------------------------------------------------
// CẬP NHẬT PHẦN RUỘT
// config.json: { remoteBase: "https://raw.githubusercontent.com/<owner>/<repo>/main/sale/" }  (kho công khai, chỉ chứa bản đã ký)
// version.json: { version, files: [{ file, world, sha256 }], sig, minShell }
//   sig = ECDSA P-256/SHA-256 trên  version + "\n" + từng dòng "file:world:sha256"
// ---------------------------------------------------------------------------
var lastError = '', lastCheckAt = 0, checking = null;
function cmpVer(a, b) {
    a = String(a || '0').split('.').map(Number); b = String(b || '0').split('.').map(Number);
    for (var i = 0; i < 3; i++) { var d = (a[i] || 0) - (b[i] || 0); if (d) return d; }
    return 0;
}
async function getJSON(url, init) { var r = await fetch(url, init || { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }
async function shellConfig() { try { return await getJSON(chrome.runtime.getURL('config.json')); } catch (e) { return {}; } }
var pubKeyP = null;
function pubKey() {
    if (!pubKeyP) pubKeyP = getJSON(chrome.runtime.getURL('pubkey.json')).then(function (j) {
        return crypto.subtle.importKey('jwk', { kty: j.kty, crv: j.crv, x: j.x, y: j.y, ext: true }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    });
    pubKeyP.catch(function () { pubKeyP = null; });
    return pubKeyP;
}
function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
function b64ToBytes(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
function ghError(status) { return status === 404 ? 'không thấy bản phát hành (HTTP 404)' : 'HTTP ' + status; }
// Nguồn tải: payload-dist/ trên máy (máy phát triển) và GitHub
function githubSource(cfg) {
    if (cfg.remoteBase) return function (f) { return fetch(cfg.remoteBase + f + '?t=' + Date.now(), { cache: 'no-store' }); };
    return null;
}
async function sources(localOnly) {
    var out = [];
    var local = function (f) { return fetch(chrome.runtime.getURL('payload-dist/' + f), { cache: 'no-store' }); };
    try { var lr = await local('version.json'); if (lr.ok) out.push({ v: await lr.json(), get: local, kind: 'local' }); } catch (e) {}
    if (localOnly) return out;
    var gh = githubSource(await shellConfig());
    if (gh) {
        try {
            var r = await gh('version.json');
            if (!r.ok) throw new Error(ghError(r.status));
            out.push({ v: await r.json(), get: gh, kind: 'github' });
        } catch (e) { lastError = 'Không đọc được bản phát hành trên GitHub: ' + e.message; }
    }
    return out;
}
async function download(src) {
    var v = src.v, files = [];
    for (var i = 0; i < v.files.length; i++) {
        var f = v.files[i];
        var r = await src.get(f.file);
        if (!r.ok) throw new Error('Không tải được ' + f.file + ' (' + ghError(r.status) + ')');
        var buf = await r.arrayBuffer();
        if (hex(await crypto.subtle.digest('SHA-256', buf)) !== f.sha256) throw new Error('SHA-256 của ' + f.file + ' không khớp');
        files.push({ file: f.file, world: f.world, code: new TextDecoder().decode(buf) });
    }
    var msg = new TextEncoder().encode(v.version + '\n' + v.files.map(function (f) { return f.file + ':' + f.world + ':' + f.sha256; }).join('\n'));
    var ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await pubKey(), b64ToBytes(v.sig), msg);
    if (!ok) throw new Error('Sai chữ ký — bỏ qua bản tải về');
    return files;
}
function userScriptsOk() {
    try { if (!chrome.userScripts || !chrome.userScripts.getScripts) return Promise.resolve(false); return chrome.userScripts.getScripts().then(function () { return true; }, function () { return false; }); }
    catch (e) { return Promise.resolve(false); }
}
async function registerPayload(files) {
    if (!(await userScriptsOk())) throw new Error('USERSCRIPTS_OFF');
    var old = await chrome.userScripts.getScripts();
    await allowPayloadMessaging();
    if (old && old.length) await chrome.userScripts.unregister({ ids: old.map(function (s) { return s.id; }) });
    await chrome.userScripts.register(files.map(function (f, i) {
        return { id: 'nhs-' + i + '-' + f.file.replace(/[^a-z0-9]/gi, '_'), matches: MATCHES, js: [{ code: f.code }], runAt: 'document_idle', world: f.world === 'MAIN' ? 'MAIN' : 'USER_SCRIPT' };
    }));
}
async function ensureRegistered() {
    var cur = (await chrome.storage.local.get('payload')).payload;
    if (!cur || !(await userScriptsOk())) return false;
    var ex = await chrome.userScripts.getScripts();
    if (!ex || ex.length !== cur.files.length || (await chrome.storage.local.get('payloadRegistered')).payloadRegistered !== cur.version) {
        await registerPayload(cur.files);
        await chrome.storage.local.set({ payloadRegistered: cur.version });
        return 'registered';
    }
    return true;
}
async function status() {
    var cur = (await chrome.storage.local.get('payload')).payload;
    var latest = (await chrome.storage.local.get('latestRemote')).latestRemote || null;
    return {
        shell: SHELL_VERSION, payload: cur ? cur.version : null, source: cur ? cur.source : null, userScripts: await userScriptsOk(),
        lastCheckAt: lastCheckAt, lastError: lastError, latest: latest && latest.version,
        shellOutdated: !!(latest && latest.minShell && cmpVer(SHELL_VERSION, latest.minShell) < 0), minShell: latest && latest.minShell
    };
}
function checkUpdate(opts) {
    opts = opts || {};
    if (checking) return checking;
    if (opts.throttle && Date.now() - lastCheckAt < 3 * 60 * 1000) return ensureRegistered().catch(function () {}).then(status);
    checking = (async function () {
        lastCheckAt = Date.now(); lastError = '';
        var cur = (await chrome.storage.local.get('payload')).payload;
        var list = await sources(opts.localOnly);
        var gh = list.find(function (s) { return s.kind === 'github'; });
        if (gh) await chrome.storage.local.set({ latestRemote: { version: gh.v.version, minShell: gh.v.minShell || null } });
        list = list.filter(function (s) { return s.v && s.v.version && s.v.sig && s.v.files && (!s.v.minShell || cmpVer(SHELL_VERSION, s.v.minShell) >= 0); });
        list.sort(function (a, b) { return cmpVer(b.v.version, a.v.version); });
        var best = list[0];
        if (best && (!cur || cmpVer(best.v.version, cur.version) > 0)) {
            var files = await download(best);
            await chrome.storage.local.set({ payload: { version: best.v.version, files: files, source: best.kind, at: Date.now() } });
            try { await registerPayload(files); await chrome.storage.local.set({ payloadRegistered: best.v.version }); }
            catch (e) { if (String(e.message) !== 'USERSCRIPTS_OFF') throw e; }
            var tabs = await chrome.tabs.query({ url: MATCHES });
            tabs.forEach(function (t) { chrome.tabs.sendMessage(t.id, { type: 'nhs:payloadUpdated', version: best.v.version }).catch(function () {}); });
        } else {
            await ensureRegistered().catch(function (e) { lastError = String(e && e.message || e); });
        }
        return status();
    })();
    checking.then(function () { checking = null; }, function (e) { lastError = String(e && e.message || e); checking = null; });
    return checking;
}
chrome.alarms.create('nhs-update', { periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'nhs-update') checkUpdate({}).catch(function () {}); });
chrome.runtime.onStartup.addListener(function () { checkUpdate({}).catch(function () {}); });

// ---------------------------------------------------------------------------
// MÁY PHÁT TRIỂN: tự reload phần vỏ khi sửa file; tự nạp bản build mới ở payload-dist/
// ---------------------------------------------------------------------------
var DEV_FILES = ['manifest.json', 'background.js', 'shell-cs.js', 'connect-cs.js', 'popup.html', 'popup.js', 'pubkey.json', 'config.json'];
var devPending = null, devBusy = null, devLocalAt = 0;
function hashStr(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + ':' + s.length; }
async function devHash() {
    var parts = await Promise.all(DEV_FILES.map(function (f) {
        return fetch(chrome.runtime.getURL(f), { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; }, function () { return ''; });
    }));
    return hashStr(parts.join('\u0000'));
}
function devCheck() {
    if (!IS_DEV) return Promise.resolve({ ok: true, dev: false });
    if (devBusy) return devBusy;
    devBusy = (async function () {
        if (Date.now() - devLocalAt > 3000) {
            devLocalAt = Date.now();
            try {
                var lv = await getJSON(chrome.runtime.getURL('payload-dist/version.json'));
                var cur = (await chrome.storage.local.get('payload')).payload;
                if (lv && (!cur || cmpVer(lv.version, cur.version) > 0)) await checkUpdate({ localOnly: true });
            } catch (e) {}
        }
        var base = (await chrome.storage.local.get('dev:hash'))['dev:hash'];
        var now = await devHash();
        if (!base) { await chrome.storage.local.set({ 'dev:hash': now }); return { ok: true, changed: false }; }
        if (now === base) { devPending = null; return { ok: true, changed: false }; }
        if (devPending !== now) { devPending = now; return { ok: true, changed: false, waiting: true }; }
        setTimeout(function () { chrome.runtime.reload(); }, 50);
        return { ok: true, changed: true };
    })();
    devBusy.then(function () { devBusy = null; }, function () { devBusy = null; });
    return devBusy;
}
chrome.runtime.onInstalled.addListener(function () {
    (async function () {
        await chrome.storage.local.remove('payloadRegistered');   // phần vỏ mới cài/nạp lại -> đăng ký lại phần ruột
        await checkUpdate({}).catch(function () {});
        if (IS_DEV) await chrome.storage.local.set({ 'dev:hash': await devHash() });
    })().catch(function () {});
});
chrome.runtime.onStartup.addListener(function () { if (IS_DEV) devHash().then(function (h) { chrome.storage.local.set({ 'dev:hash': h }); }).catch(function () {}); });
