// Nhanh vn Đại Dương (Sale) — phần vỏ chạy trên nhanh.vn (content script cố định, cài 1 lần).
// - Hỏi background kiểm tra bản mới của "phần ruột" mỗi khi mở nhanh.vn
// - Báo khi có bản mới (không tự tải lại trang: có thể đang soạn đơn dở), khi chưa bật "Cho phép tập lệnh người dùng",
//   khi phần vỏ quá cũ hoặc chưa tải được phần ruột
// - Nhắc kết nối Bảng giá (mã kết nối riêng từng người, chỉ đọc bảng giá khách của mình); báo cho phần ruột khi kết nối đổi
// - Máy phát triển (Load unpacked từ thư mục dự án): tự reload khi sửa file
(function () {
  'use strict';
  if (window.__nhsShell) return;
  window.__nhsShell = true;

  function banner(id, html, buttons, closeText) {
    var old = document.getElementById(id);
    if (old) old.remove();
    var b = document.createElement('div');
    b.id = id;
    b.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483000;background:#0f766e;color:#fff;padding:10px 14px;border-radius:10px;font:13px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);max-width:min(520px,calc(100vw - 32px))';
    b.innerHTML = html;
    (buttons || []).concat([{ text: closeText || 'Để sau', link: true, fn: function () { b.remove(); } }]).forEach(function (bt) {
      var e = document.createElement(bt.link ? 'a' : 'button');
      e.textContent = bt.text;
      if (bt.link) { e.href = '#'; e.style.cssText = 'color:#ccfbf1;margin-left:10px'; }
      else e.style.cssText = 'margin-left:8px;background:#fff;color:#0f766e;border:0;border-radius:6px;padding:4px 10px;font-weight:600;cursor:pointer';
      e.onclick = function (ev) { ev.preventDefault(); bt.fn(); };
      b.appendChild(e);
    });
    (document.body || document.documentElement).appendChild(b);
  }
  function send(msg) {
    return new Promise(function (resolve) {
      try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; resolve(r); }); } catch (e) { resolve(null); }
    });
  }
  var reloadBtn = { text: 'Tải lại trang', fn: function () { location.reload(); } };
  var saveHint = ' (lưu đơn đang soạn trước khi tải lại)';

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (msg && msg.type === 'nhs:payloadUpdated')
        banner('nhs-shell-upd', '🔄 Extension Nhanh Sale có bản mới <b>v' + msg.version + '</b>. Tải lại trang để dùng' + saveHint + '.', [reloadBtn]);
    });
  } catch (e) {}

  function showStatus(st) {
    if (!st) return;
    if (!st.userScripts) {
      banner('nhs-shell-perm', '⚙ Extension <b>Nhanh vn Đại Dương (Sale)</b> cần bật <b>"Cho phép tập lệnh người dùng"</b> (Allow User Scripts): mở trang chi tiết extension → bật công tắc đó, rồi tải lại trang.',
        [{ text: 'Mở cài đặt extension', fn: function () { send({ type: 'nhs:openExtSettings' }); } }]);
      return;
    }
    if (st.shellOutdated)
      banner('nhs-shell-old', '⬆ Phần vỏ extension Nhanh Sale đã cũ (v' + st.shell + ', cần ≥ v' + st.minShell + '). Tải gói cài mới tại github.com/trithucnguyen97/duyet-bao-gia (install/NhanhSale.zip), giải nén đè vào thư mục cũ rồi bấm tải lại (↻) ở chrome://extensions.');
    if (!st.payload) {
      banner('nhs-shell-none', '⚠ Extension Nhanh Sale chưa tải được phần chính' + (st.lastError ? ': ' + String(st.lastError).replace(/</g, '&lt;') : '') + '.',
        [{ text: 'Thử lại', fn: function () { send({ type: 'nhs:checkUpdate', force: true }).then(showStatus); } }]);
      return;
    }
    // Vừa bật quyền / vừa cài: phần ruột chưa chạy trên trang đang mở -> nhắc tải lại
    setTimeout(function () {
      if (document.documentElement.getAttribute('data-nhs-payload')) return;
      banner('nhs-shell-load', 'Extension Nhanh Sale v' + st.payload + ' đã sẵn sàng. Tải lại trang để bật' + saveHint + '.', [reloadBtn]);
    }, 5000);
  }
  send({ type: 'nhs:checkUpdate' }).then(showStatus);

  // Kết nối Bảng giá: nhắc khi chưa kết nối / bị thu hồi; bấm "Để sau" thì 3 ngày sau mới nhắc lại (nút Kết nối luôn có ở biểu tượng extension)
  var BG_LATER_KEY = 'nhs-bg-later', BG_LATER_MS = 3 * 24 * 60 * 60 * 1000;
  function bgSnoozed() { try { return Date.now() - Number(localStorage.getItem(BG_LATER_KEY) || 0) < BG_LATER_MS; } catch (e) { return false; } }
  function bgCheck() {
    return send({ type: 'nhs:bgStatus' }).then(function (st) {
      var old = document.getElementById('nhs-shell-bg');
      if (old) old.remove();
      if (!st || st.connected || bgSnoozed()) return st;
      banner('nhs-shell-bg', (st.expired ? '🔒 Kết nối <b>Bảng giá</b> đã hết hiệu lực (bị thu hồi).' : '🔗 Chưa kết nối <b>Bảng giá</b>.') +
        ' Kết nối bằng tài khoản Bảng giá của bạn để hiện giá theo từng khách trên đơn.',
        [{ text: 'Kết nối Bảng giá', fn: function () { send({ type: 'nhs:bgConnect' }); } }]);
      var later = document.querySelector('#nhs-shell-bg a');
      if (later) later.addEventListener('click', function () { try { localStorage.setItem(BG_LATER_KEY, String(Date.now())); } catch (e) {} });
      return st;
    });
  }
  bgCheck();
  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (!msg || msg.type !== 'nhs:bgChanged') return;
      try { localStorage.removeItem(BG_LATER_KEY); } catch (e) {}
      // Phần ruột nghe sự kiện này để tra lại khách / bỏ giá đang hiện, không cần tải lại trang
      try { window.dispatchEvent(new CustomEvent('nhs-bg-changed')); } catch (e) {}
      bgCheck().then(function (st) {
        if (st && st.connected) banner('nhs-shell-bg', '✅ Đã kết nối Bảng giá (' + String(st.user || '').replace(/</g, '&lt;') + '). Đơn có SĐT khách đã lưu trong Bảng giá sẽ hiện giá theo khách.', [], 'Đóng');
      });
    });
  } catch (e) {}

  (function devAutoReload() {
    var isDev = false;
    try { isDev = !('update_url' in chrome.runtime.getManifest()); } catch (e) {}
    if (!isDev) return;
    var timer = null;
    function orphaned() { try { return !chrome.runtime || !chrome.runtime.id; } catch (e) { return true; } }
    function gone() { clearInterval(timer); banner('nhs-shell-upd', '🔄 Extension Nhanh Sale vừa nạp lại. Tải lại trang để dùng bản mới' + saveHint + '.', [reloadBtn]); }
    function check() {
      if (orphaned()) { gone(); return; }
      if (document.visibilityState !== 'visible') return;
      try { chrome.runtime.sendMessage({ type: 'nhs:devcheck' }, function () { void chrome.runtime.lastError; if (orphaned()) gone(); }); } catch (e) { gone(); }
    }
    timer = setInterval(check, 2000);
    document.addEventListener('visibilitychange', check);
  })();
})();
