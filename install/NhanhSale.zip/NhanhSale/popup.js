// Popup: trạng thái kết nối Bảng giá (mã kết nối riêng từng người, chỉ đọc bảng giá khách) + phiên bản
function send(msg) { return new Promise(function (r) { chrome.runtime.sendMessage(msg, function (res) { void chrome.runtime.lastError; r(res); }); }); }
function btn(text, ghost, fn) { var b = document.createElement('button'); b.textContent = text; if (ghost) b.className = 'ghost'; b.onclick = fn; return b; }
async function render() {
  var bg = await send({ type: 'nhs:bgStatus' }), st = await send({ type: 'nhs:status' });
  var box = document.getElementById('bg'), hint = document.getElementById('hint'), act = document.getElementById('actions');
  act.innerHTML = '';
  if (bg && bg.connected) {
    box.textContent = '✅ Đã kết nối Bảng giá: ' + (bg.user || '(không rõ tên)');
    hint.textContent = 'Đơn có SĐT khách đã lưu trong Bảng giá sẽ hiện giá theo bảng giá của khách đó.';
    act.appendChild(btn('Ngắt kết nối', true, async function () { await send({ type: 'nhs:bgLogout' }); render(); }));
  } else {
    box.textContent = bg && bg.expired ? '🔒 Kết nối Bảng giá đã bị thu hồi.' : '🔗 Chưa kết nối Bảng giá.';
    hint.textContent = 'Kết nối bằng tài khoản Bảng giá của bạn để hiện giá theo từng khách trên đơn. QR và upload ảnh vẫn chạy khi chưa kết nối.';
    act.appendChild(btn('Kết nối Bảng giá', false, function () { send({ type: 'nhs:bgConnect' }); window.close(); }));
  }
  if (st) document.getElementById('ver').textContent = 'Phần vỏ v' + st.shell + ' · phần chính ' + (st.payload ? 'v' + st.payload : 'chưa tải') + (st.userScripts ? '' : ' · CHƯA bật "Cho phép tập lệnh người dùng"');
}
render();
