// Duyệt Báo Giá — phần vỏ (service worker), cài 1 lần trên mỗi máy.
// 1) Tự cập nhật "phần ruột" (logic phân tích + giao diện) từ GitHub: đọc version.json, kiểm SHA-256 + chữ ký ECDSA,
//    lưu vào chrome.storage.local và đăng ký chạy trên trang CRM bằng chrome.userScripts.
// 2) Cầu nối cho phần ruột: lưu cài đặt (chrome.storage.sync), OCR offline (Tesseract.js trong offscreen).
// 3) Máy phát triển: tự reload khi sửa file, tự nạp bản build mới ở dist/.
//
// OCR: nhận yêu cầu, chuyển cho trang offscreen, cache kết quả theo URL ảnh trong chrome.storage.local.
var OFFSCREEN_URL = 'offscreen.html';
var creating = null;

function ensureOffscreen() {
  if (creating) return creating;
  creating = (async function () {
    try {
      if (chrome.runtime.getContexts) {
        var ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
        if (ctx && ctx.length) return;
      }
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_URL,
        reasons: ['DOM_SCRAPING'],
        justification: 'Chạy OCR (Tesseract.js) ảnh báo giá của khách ngay trên máy, không gửi ra ngoài'
      });
    } catch (e) {
      if (!/already|exists|single offscreen/i.test(String(e && e.message))) throw e;
    }
  })();
  creating.then(function () { creating = null; }, function () { creating = null; });
  return creating;
}

function cacheKey(img) { return 'ocr:' + (img.url || ('data:' + hashStr(img.dataUrl || ''))); }
function hashStr(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + ':' + s.length; }

async function ocrOne(img, opts, tabId) {
  var key = cacheKey(img);
  if (!opts.force) {
    var c = await chrome.storage.local.get(key);
    if (c && c[key] && c[key].lines) return Object.assign({ cached: true }, c[key]);
  }
  await ensureOffscreen();
  var res = await chrome.runtime.sendMessage({ target: 'ddbg-offscreen', type: 'ocr', image: img, tabId: tabId });
  if (!res) throw new Error('Offscreen không trả lời');
  if (res.error) throw new Error(res.error);
  var store = {}; store[key] = { lines: res.lines, w: res.w, h: res.h, ms: res.ms, at: Date.now() };
  try { await chrome.storage.local.set(store); } catch (e) {}
  return res;
}

var CRM_MATCHES = ['https://quanly.baobidaiduong.com/*', 'https://crm.bangkeohaiau.com/*'];
var SHELL_VERSION = chrome.runtime.getManifest().version;
var IS_DEV = !('update_url' in chrome.runtime.getManifest());

// ---------------------------------------------------------------------------
// TIN NHẮN: từ phần vỏ trên trang (onMessage), từ phần ruột (onUserScriptMessage), từ offscreen
// ---------------------------------------------------------------------------
function route(msg, sender, sendResponse) {
  if (!msg || msg.target === 'ddbg-offscreen') return;
  if (msg.type === 'ddbg:ocr') {
    var tabId = sender.tab && sender.tab.id;
    (async function () {
      var out = [];
      for (var i = 0; i < msg.images.length; i++) {
        var img = msg.images[i];
        try { out.push(Object.assign({ ok: true, url: img.url || null, name: img.name || null }, await ocrOne(img, msg.opts || {}, tabId))); }
        catch (e) { out.push({ ok: false, url: img.url || null, name: img.name || null, error: String(e && e.message || e) }); }
      }
      sendResponse({ ok: true, results: out });
    })().catch(function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); });
    return true;
  }
  if (msg.type === 'ddbg:ocrProgress') {   // offscreen -> tab (phần vỏ trên trang chuyển tiếp cho phần ruột)
    if (msg.tabId) chrome.tabs.sendMessage(msg.tabId, msg).catch(function () {});
    return;
  }
  if (msg.type === 'ddbg:ocrClearCache') {
    chrome.storage.local.get(null).then(function (all) {
      var keys = Object.keys(all || {}).filter(function (k) { return k.indexOf('ocr:') === 0; });
      return chrome.storage.local.remove(keys).then(function () { sendResponse({ ok: true, removed: keys.length }); });
    });
    return true;
  }
  if (msg.type === 'ddbg:storageGet') {
    chrome.storage.sync.get(msg.keys === undefined ? null : msg.keys).then(sendResponse, function () { sendResponse(null); });
    return true;
  }
  if (msg.type === 'ddbg:storageSet') {
    chrome.storage.sync.set(msg.items || {}).then(function () { sendResponse({ ok: true }); }, function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); });
    return true;
  }
  if (msg.type === 'ddbg:checkUpdate') {
    checkUpdate({ throttle: !msg.force }).then(sendResponse, function (e) { status().then(function (st) { st.lastError = String(e && e.message || e); sendResponse(st); }); });
    return true;
  }
  if (msg.type === 'ddbg:status') { status().then(sendResponse); return true; }
  if (msg.type === 'ddbg:openExtSettings') { chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); return; }
  if (msg.type === 'ddbg:devcheck') {
    devCheck().then(sendResponse, function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); });
    return true;
  }
}
chrome.runtime.onMessage.addListener(route);
if (chrome.runtime.onUserScriptMessage) chrome.runtime.onUserScriptMessage.addListener(route);

// ---------------------------------------------------------------------------
// CẬP NHẬT PHẦN RUỘT TỪ GITHUB
// ---------------------------------------------------------------------------
var lastError = '', lastCheckAt = 0, latestSeen = null, checking = null;
function cmpVer(a, b) {
  a = String(a || '0').split('.').map(Number); b = String(b || '0').split('.').map(Number);
  for (var i = 0; i < 3; i++) { var d = (a[i] || 0) - (b[i] || 0); if (d) return d; }
  return 0;
}
async function getJSON(url) {
  var r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
async function shellConfig() { try { return await getJSON(chrome.runtime.getURL('config.json')); } catch (e) { return {}; } }
var pubKeyP = null;
function pubKey() {
  if (!pubKeyP) pubKeyP = getJSON(chrome.runtime.getURL('pubkey.json')).then(function (j) {
    return crypto.subtle.importKey('jwk', { kty: j.kty, crv: j.crv, x: j.x, y: j.y, ext: true }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  });
  pubKeyP.catch(function () { pubKeyP = null; });
  return pubKeyP;
}
function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
function b64ToBytes(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
async function verifyBundle(v, buf) {
  var h = hex(await crypto.subtle.digest('SHA-256', buf));
  if (h !== v.sha256) throw new Error('SHA-256 không khớp');
  var head = new TextEncoder().encode(v.version + '\n');
  var data = new Uint8Array(head.length + buf.byteLength); data.set(head, 0); data.set(new Uint8Array(buf), head.length);
  var ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await pubKey(), b64ToBytes(v.sig), data);
  if (!ok) throw new Error('Sai chữ ký — bỏ qua bản tải về');
}
async function sources(localOnly) {
  var out = [];
  // Máy phát triển: bản build ở dist/ trong thư mục extension (máy nhân viên không có thư mục này)
  try { out.push({ v: await getJSON(chrome.runtime.getURL('dist/version.json')), base: chrome.runtime.getURL('dist/'), kind: 'local' }); } catch (e) {}
  if (localOnly) return out;
  var cfg = await shellConfig();
  if (cfg.remoteBase) {
    try {
      var v = await getJSON(cfg.remoteBase + 'version.json?t=' + Date.now());
      latestSeen = v.version; out.push({ v: v, base: cfg.remoteBase, kind: 'github' });
    } catch (e) { lastError = 'Không đọc được version.json trên GitHub (' + e.message + ')'; }
  }
  return out;
}
function userScriptsOk() {
  try { if (!chrome.userScripts || !chrome.userScripts.getScripts) return Promise.resolve(false); return chrome.userScripts.getScripts().then(function () { return true; }, function () { return false; }); }
  catch (e) { return Promise.resolve(false); }
}
async function registerPayload(code) {
  if (!(await userScriptsOk())) throw new Error('USERSCRIPTS_OFF');
  try { await chrome.userScripts.configureWorld({ messaging: true }); } catch (e) {}
  var def = { id: 'ddbg-main', matches: CRM_MATCHES, js: [{ code: code }], runAt: 'document_idle', world: 'USER_SCRIPT' };
  var ex = await chrome.userScripts.getScripts({ ids: ['ddbg-main'] });
  if (ex && ex.length) await chrome.userScripts.update([def]); else await chrome.userScripts.register([def]);
}
async function ensureRegistered() {
  var cur = (await chrome.storage.local.get('payload')).payload;
  if (!cur || !(await userScriptsOk())) return false;
  var ex = await chrome.userScripts.getScripts({ ids: ['ddbg-main'] });
  if (!ex || !ex.length || (await chrome.storage.local.get('payloadRegistered')).payloadRegistered !== cur.version) {
    await registerPayload(cur.code);
    await chrome.storage.local.set({ payloadRegistered: cur.version });
    return 'registered';
  }
  return true;
}
async function notifyTabs(version) {
  var tabs = await chrome.tabs.query({ url: CRM_MATCHES });
  tabs.forEach(function (t) { chrome.tabs.sendMessage(t.id, { type: 'ddbg:payloadUpdated', version: version }).catch(function () {}); });
}
async function status() {
  var cur = (await chrome.storage.local.get('payload')).payload;
  var cfg = await shellConfig();
  var latest = null;
  try { latest = (await chrome.storage.local.get('latestRemote')).latestRemote || null; } catch (e) {}
  return {
    shell: SHELL_VERSION, payload: cur ? cur.version : null, source: cur ? cur.source : null, userScripts: await userScriptsOk(),
    remoteBase: cfg.remoteBase || '', installUrl: cfg.installUrl || '', lastCheckAt: lastCheckAt, lastError: lastError,
    shellOutdated: !!(latest && latest.minShell && cmpVer(SHELL_VERSION, latest.minShell) < 0), minShell: latest && latest.minShell, latest: latest && latest.version
  };
}
function checkUpdate(opts) {
  opts = opts || {};
  if (checking) return checking;
  if (opts.throttle && Date.now() - lastCheckAt < 3 * 60 * 1000) return ensureRegistered().catch(function () {}).then(status);
  checking = (async function () {
    lastCheckAt = Date.now(); lastError = '';
    var cur = (await chrome.storage.local.get('payload')).payload;
    var list = await sources(opts.localOnly);
    var gh = list.find(function (s) { return s.kind === 'github'; });
    if (gh) await chrome.storage.local.set({ latestRemote: { version: gh.v.version, minShell: gh.v.minShell || null } });
    list = list.filter(function (s) { return s.v && s.v.version && s.v.sig && (!s.v.minShell || cmpVer(SHELL_VERSION, s.v.minShell) >= 0); });
    list.sort(function (a, b) { return cmpVer(b.v.version, a.v.version); });
    var best = list[0];
    if (best && (!cur || cmpVer(best.v.version, cur.version) > 0)) {
      var r = await fetch(best.base + best.v.file + (best.kind === 'github' ? '?v=' + encodeURIComponent(best.v.version) : ''), { cache: 'no-store' });
      if (!r.ok) throw new Error('Không tải được ' + best.v.file + ' (HTTP ' + r.status + ')');
      var buf = await r.arrayBuffer();
      await verifyBundle(best.v, buf);
      var code = new TextDecoder().decode(buf);
      await chrome.storage.local.set({ payload: { version: best.v.version, code: code, source: best.kind, at: Date.now() } });
      try { await registerPayload(code); await chrome.storage.local.set({ payloadRegistered: best.v.version }); }
      catch (e) { if (String(e.message) !== 'USERSCRIPTS_OFF') throw e; }
      await notifyTabs(best.v.version);
    } else {
      await ensureRegistered().catch(function (e) { lastError = String(e && e.message || e); });
    }
    return status();
  })();
  checking.then(function () { checking = null; }, function (e) { lastError = String(e && e.message || e); checking = null; });
  return checking;
}
chrome.alarms.create('ddbg-update', { periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'ddbg-update') checkUpdate({}).catch(function () {}); });
chrome.runtime.onStartup.addListener(function () { checkUpdate({}).catch(function () {}); });

// ---------------------------------------------------------------------------
// MÁY PHÁT TRIỂN (Load unpacked từ thư mục dự án): tự reload phần vỏ khi sửa file; tự nạp bản build mới ở dist/
// ---------------------------------------------------------------------------
var DEV_FILES = ['manifest.json', 'background.js', 'shell-cs.js', 'bridge.js', 'offscreen.js', 'offscreen.html', 'pubkey.json', 'config.json'];
var devPending = null, devBusy = null, devLocalAt = 0;
async function devHash() {
  var parts = await Promise.all(DEV_FILES.map(function (f) {
    return fetch(chrome.runtime.getURL(f), { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; }, function () { return ''; });
  }));
  return hashStr(parts.join('\u0000'));
}
async function devBaseline() { var h = await devHash(); await chrome.storage.local.set({ 'dev:hash': h }); return h; }
function devCheck() {
  if (!IS_DEV) return Promise.resolve({ ok: true, dev: false });
  if (devBusy) return devBusy;
  devBusy = (async function () {
    // bản build mới ở dist/ -> nạp ngay (không cần reload cả extension)
    if (Date.now() - devLocalAt > 3000) {
      devLocalAt = Date.now();
      try {
        var lv = await getJSON(chrome.runtime.getURL('dist/version.json'));
        var cur = (await chrome.storage.local.get('payload')).payload;
        if (lv && (!cur || cmpVer(lv.version, cur.version) > 0)) await checkUpdate({ localOnly: true });
      } catch (e) {}
    }
    var got = await chrome.storage.local.get('dev:hash');
    var base = got && got['dev:hash'];
    var now = await devHash();
    if (!base) { await chrome.storage.local.set({ 'dev:hash': now }); return { ok: true, dev: true, changed: false }; }
    if (now === base) { devPending = null; return { ok: true, dev: true, changed: false }; }
    if (devPending !== now) { devPending = now; return { ok: true, dev: true, changed: false, waiting: true }; }
    await chrome.storage.local.set({ 'dev:reloadTabs': Date.now() });
    setTimeout(function () { chrome.runtime.reload(); }, 50);
    return { ok: true, dev: true, changed: true };
  })();
  devBusy.then(function () { devBusy = null; }, function () { devBusy = null; });
  return devBusy;
}
chrome.runtime.onInstalled.addListener(function () {
  (async function () {
    await chrome.storage.local.remove('payloadRegistered');   // phần vỏ mới cài/nạp lại -> đăng ký lại phần ruột
    await checkUpdate({}).catch(function () {});
    if (!IS_DEV) return;
    await devBaseline();
    var got = await chrome.storage.local.get('dev:reloadTabs');
    var at = got && got['dev:reloadTabs'];
    if (!at) return;
    await chrome.storage.local.remove('dev:reloadTabs');
    if (Date.now() - at > 60000) return;
    var tabs = await chrome.tabs.query({ url: CRM_MATCHES });
    tabs.forEach(function (t) {
      var path = '';
      try { path = new URL(t.url).pathname; } catch (e) {}
      if (/^\/bao-gia\/?$/.test(path)) chrome.tabs.reload(t.id);
    });
  })().catch(function () {});
});
chrome.runtime.onStartup.addListener(function () { if (IS_DEV) devBaseline().catch(function () {}); });
