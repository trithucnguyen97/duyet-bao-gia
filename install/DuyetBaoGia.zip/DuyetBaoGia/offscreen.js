// Trang offscreen: tải ảnh, tiền xử lý (xóa kẻ bảng, phóng to, nhị phân) rồi OCR bằng Tesseract.js (vie+eng, offline).
(function () {
  var workerPromise = null;
  var busy = Promise.resolve();

  function getWorker() {
    if (workerPromise) return workerPromise;
    var base = chrome.runtime.getURL('vendor/');
    workerPromise = Tesseract.createWorker(['vie', 'eng'], 1, {
      workerPath: base + 'worker.min.js',
      corePath: base,
      langPath: base + 'lang',
      gzip: true,
      cacheMethod: 'none',
      workerBlobURL: false,
      logger: function () {}
    }).then(function (w) {
      return w.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' }).then(function () { return w; });
    }).catch(function (e) { workerPromise = null; throw e; });
    return workerPromise;
  }

  function loadImage(img) {
    var p;
    if (img.dataUrl) p = fetch(img.dataUrl).then(function (r) { return r.blob(); });
    else p = fetch(img.url, { cache: 'force-cache' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status + ' khi tải ảnh'); return r.blob(); });
    return p.then(function (b) { return createImageBitmap(b); });
  }

  // Trả về canvas đã xử lý + hệ số phóng to
  function preprocess(bmp, mode) {
    var w = bmp.width, h = bmp.height;
    var c0 = document.createElement('canvas'); c0.width = w; c0.height = h;
    var g0 = c0.getContext('2d', { willReadFrequently: true });
    g0.fillStyle = '#fff'; g0.fillRect(0, 0, w, h);
    g0.drawImage(bmp, 0, 0);
    var id = g0.getImageData(0, 0, w, h), d = id.data;
    var gray = new Uint8ClampedArray(w * h);
    for (var i = 0, j = 0; i < d.length; i += 4, j++) gray[j] = (d[i] * 299 + d[i + 1] * 587 + d[i + 2] * 114) / 1000;
    // Xóa đường kẻ bảng: hàng/cột có > 50% điểm tối
    var TH = 160;
    var rowDark = new Uint32Array(h), colDark = new Uint32Array(w);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) if (gray[y * w + x] < TH) { rowDark[y]++; colDark[x]++; }
    for (y = 0; y < h; y++) if (rowDark[y] > w * 0.5) for (x = 0; x < w; x++) gray[y * w + x] = 255;
    for (x = 0; x < w; x++) if (colDark[x] > h * 0.5) for (y = 0; y < h; y++) gray[y * w + x] = 255;
    for (i = 0, j = 0; i < d.length; i += 4, j++) { d[i] = d[i + 1] = d[i + 2] = gray[j]; d[i + 3] = 255; }
    g0.putImageData(id, 0, 0);
    // Phóng to (×4, tối đa cạnh 4000px) rồi nhị phân
    var scale = Math.max(1, Math.min(4, 4000 / Math.max(w, h)));
    var W = Math.round(w * scale), H = Math.round(h * scale);
    var c1 = document.createElement('canvas'); c1.width = W; c1.height = H;
    var g1 = c1.getContext('2d', { willReadFrequently: true });
    g1.imageSmoothingEnabled = true; g1.imageSmoothingQuality = 'high';
    g1.drawImage(c0, 0, 0, W, H);
    if (mode !== 'gray') {
      var id1 = g1.getImageData(0, 0, W, H), d1 = id1.data;
      for (i = 0; i < d1.length; i += 4) { var v = d1[i] > TH ? 255 : 0; d1[i] = d1[i + 1] = d1[i + 2] = v; }
      g1.putImageData(id1, 0, 0);
    }
    return { canvas: c1, scale: scale, w: w, h: h };
  }

  function linesOf(data, scale) {
    return (data.lines || []).map(function (l) {
      return { text: (l.text || '').replace(/\s+/g, ' ').trim(), conf: Math.round(l.confidence || 0), y0: Math.round(l.bbox.y0 / scale), y1: Math.round(l.bbox.y1 / scale), x0: Math.round(l.bbox.x0 / scale), x1: Math.round(l.bbox.x1 / scale) };
    }).filter(function (l) { return l.text; });
  }

  function progress(tabId, text, pct) {
    try { chrome.runtime.sendMessage({ type: 'ddbg:ocrProgress', tabId: tabId, text: text, pct: pct }); } catch (e) {}
  }

  async function recognize(img, tabId) {
    var t0 = Date.now();
    progress(tabId, 'Đang nạp bộ OCR (lần đầu mất vài giây)…', 5);
    var w = await getWorker();
    progress(tabId, 'Đang tải ảnh…', 15);
    var bmp = await loadImage(img);
    progress(tabId, 'Đang xử lý ảnh (' + bmp.width + '×' + bmp.height + ')…', 25);
    var pre = preprocess(bmp, 'bin');
    progress(tabId, 'Đang đọc chữ…', 40);
    await w.setParameters({ tessedit_char_whitelist: '' });
    var r1 = await w.recognize(pre.canvas);
    var lines = linesOf(r1.data, pre.scale);
    // Lượt 2: chỉ số (để bắt giá bị sót) — ghép theo vị trí dòng
    progress(tabId, 'Đang đọc lại cột số…', 75);
    await w.setParameters({ tessedit_char_whitelist: '0123456789.,xX ' });
    var r2 = await w.recognize(pre.canvas);
    var digitLines = linesOf(r2.data, pre.scale);
    await w.setParameters({ tessedit_char_whitelist: '' });
    lines.forEach(function (l) {
      var mid = (l.y0 + l.y1) / 2;
      var m = digitLines.find(function (q) { return mid >= q.y0 - 2 && mid <= q.y1 + 2; });
      if (m) l.digits = m.text;
    });
    digitLines.forEach(function (q) {
      var mid = (q.y0 + q.y1) / 2;
      if (!lines.some(function (l) { return mid >= l.y0 - 2 && mid <= l.y1 + 2; })) lines.push({ text: q.text, digits: q.text, conf: q.conf, y0: q.y0, y1: q.y1, x0: q.x0, x1: q.x1, digitsOnly: true });
    });
    lines.sort(function (a, b) { return a.y0 - b.y0; });
    progress(tabId, 'Xong', 100);
    return { lines: lines, w: pre.w, h: pre.h, ms: Date.now() - t0 };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.target !== 'ddbg-offscreen') return;
    if (msg.type === 'ocr') {
      busy = busy.then(function () { return recognize(msg.image, msg.tabId); })
        .then(function (res) { sendResponse(res); }, function (e) { sendResponse({ error: String(e && e.message || e) }); });
      return true;
    }
    if (msg.type === 'ping') { sendResponse({ ok: true }); }
  });
})();
