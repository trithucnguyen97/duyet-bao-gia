// Đại Dương - Duyệt Báo Giá: cầu nối chạy trong ngữ cảnh trang (world: MAIN)
// Content script không thấy được dữ liệu React của trang, nên phần này nhận lệnh qua CustomEvent
// và ghi dealValue / dealPercent thẳng vào bản ghi sản phẩm của bảng hàng hóa (giống "Set deal cho BG").
(function () {
  'use strict';
  function findRows() {
    var tables = document.querySelectorAll('table');
    for (var i = 0; i < tables.length; i++) {
      var table = tables[i];
      if (table.closest('.ddbg-detail') || table.closest('.ddbg-rowdetail')) continue;
      var ths = Array.prototype.filter.call(table.querySelectorAll('thead th'), function (th) { return !th.classList.contains('ant-table-cell-scrollbar'); });
      var ok = false;
      for (var j = 0; j < ths.length; j++) if (ths[j].textContent.trim() === 'Giá thực bán') { ok = true; break; }
      if (!ok) continue;
      var container = table.closest('.ant-table') || table.parentElement;
      var rows = Array.prototype.slice.call(container.querySelectorAll('.ant-table-body tr.ant-table-row'));
      if (!rows.length) rows = Array.prototype.slice.call(container.querySelectorAll('tbody tr.ant-table-row'));
      if (rows.length) return rows;
    }
    return [];
  }
  function recordOf(tr) {
    var key = Object.keys(tr).find(function (k) { return k.indexOf('__reactFiber$') === 0; });
    var f = key ? tr[key] : null, hops = 0;
    while (f && hops < 20) {
      var p = f.memoizedProps;
      if (p && p.record && typeof p.record === 'object' && ('dealValue' in p.record || 'price' in p.record)) return p.record;
      f = f.return; hops++;
    }
    return null;
  }
  window.addEventListener('ddbg:setDeal', function (e) {
    var out = { ok: false, done: [], failed: [] };
    try {
      var d = JSON.parse(e.detail || '{}');
      var rows = findRows();
      (d.items || []).forEach(function (it) {
        var tr = rows.find(function (r) { var rec = recordOf(r); return rec && rec.id === it.productId; });
        if (!tr) tr = rows[it.idx - 1];
        var rec = tr ? recordOf(tr) : null;
        if (!rec) { out.failed.push(it.idx); return; }
        if (it.dealValue !== undefined && it.dealValue !== null) rec.dealValue = it.dealValue;
        if (it.dealPercent !== undefined && it.dealPercent !== null) rec.dealPercent = it.dealPercent;
        out.done.push(it.idx);
      });
      out.ok = true;
    } catch (err) { out.error = String(err && err.message || err); }
    window.dispatchEvent(new CustomEvent('ddbg:setDealDone', { detail: JSON.stringify(out) }));
  });
  window.__ddbgBridgeReady = true;
  window.dispatchEvent(new CustomEvent('ddbg:bridgeReady'));
})();
