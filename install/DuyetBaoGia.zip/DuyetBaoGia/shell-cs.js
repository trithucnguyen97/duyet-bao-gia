// Duyệt Báo Giá — phần vỏ chạy trên trang CRM (content script cố định, cài 1 lần).
// - Hỏi background kiểm tra bản mới của "phần ruột" trên GitHub mỗi khi mở CRM
// - Chuyển sự kiện từ background (tiến độ OCR, có bản mới) cho phần ruột qua CustomEvent 'ddbg-host'
// - Báo khi chưa bật quyền "Cho phép tập lệnh người dùng" (User Scripts) hoặc phần vỏ quá cũ
// - Máy phát triển (Load unpacked từ thư mục dự án): tự reload khi sửa file
(function () {
  'use strict';
  if (window.__ddbgShell) return;
  window.__ddbgShell = true;
  var isListPage = function () { return /^\/bao-gia\/?$/.test(location.pathname); };

  function banner(id, html, buttons) {
    var old = document.getElementById(id);
    if (old) old.remove();
    var b = document.createElement('div');
    b.id = id; b.className = 'ddbg-shellbar';
    b.style.cssText = 'position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:2147483000;background:#1e3a8a;color:#fff;padding:10px 14px;border-radius:10px;font:13px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);max-width:calc(100vw - 32px)';
    b.innerHTML = html;
    (buttons || []).concat([{ text: 'Để sau', link: true, fn: function () { b.remove(); } }]).forEach(function (bt) {
      var e = document.createElement(bt.link ? 'a' : 'button');
      e.textContent = bt.text;
      if (bt.link) { e.href = '#'; e.style.cssText = 'color:#c7d2fe;margin-left:10px'; }
      else e.style.cssText = 'margin-left:8px;background:#fff;color:#1e3a8a;border:0;border-radius:6px;padding:4px 10px;font-weight:600;cursor:pointer';
      e.onclick = function (ev) { ev.preventDefault(); bt.fn(); };
      b.appendChild(e);
    });
    (document.body || document.documentElement).appendChild(b);
  }
  function send(msg) {
    return new Promise(function (resolve) {
      try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; resolve(r); }); } catch (e) { resolve(null); }
    });
  }
  function toHost(msg) { document.dispatchEvent(new CustomEvent('ddbg-host', { detail: JSON.stringify(msg) })); }

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (!msg || !msg.type) return;
      if (msg.type === 'ddbg:ocrProgress') toHost(msg);
      if (msg.type === 'ddbg:payloadUpdated') {
        if (isListPage()) { location.reload(); return; }
        banner('ddbg-shell-upd', '🔄 Duyệt Báo Giá có bản mới <b>v' + msg.version + '</b>. Tải lại trang để dùng' +
          (/\/update\//.test(location.pathname) ? ' (bấm "Cập nhật" lưu giá trước nếu đang sửa dở)' : '') + '.',
          [{ text: 'Tải lại trang', fn: function () { location.reload(); } }]);
      }
    });
  } catch (e) {}

  function showStatus(st) {
    if (!st) return;
    if (!st.userScripts) {
      banner('ddbg-shell-perm', '⚙ Duyệt Báo Giá cần bật <b>"Cho phép tập lệnh người dùng"</b> (Allow User Scripts): mở trang chi tiết extension → bật công tắc đó, rồi tải lại trang CRM.',
        [{ text: 'Mở cài đặt extension', fn: function () { send({ type: 'ddbg:openExtSettings' }); } }]);
      return;
    }
    if (st.shellOutdated) {
      banner('ddbg-shell-old', '⬆ Phần vỏ extension Duyệt Báo Giá đã cũ (v' + st.shell + ', cần ≥ v' + st.minShell + '). Tải bản mới và cài lại theo hướng dẫn.',
        st.installUrl ? [{ text: 'Mở hướng dẫn', fn: function () { window.open(st.installUrl, '_blank'); } }] : []);
    }
    if (!st.payload) {
      banner('ddbg-shell-none', '⚠ Duyệt Báo Giá chưa tải được phần phân tích' + (st.lastError ? ': ' + String(st.lastError).replace(/</g, '&lt;') : '') + '.',
        [{ text: 'Thử lại', fn: function () { send({ type: 'ddbg:checkUpdate', force: true }).then(showStatus); } }]);
      return;
    }
    // Vừa bật quyền / vừa cài: phần ruột chưa chạy trên trang đang mở -> tải lại (trang danh sách) hoặc nhắc
    setTimeout(function () {
      if (document.documentElement.getAttribute('data-ddbg-payload')) return;
      if (isListPage() && !sessionStorage.getItem('ddbg-autoreload')) { sessionStorage.setItem('ddbg-autoreload', '1'); location.reload(); return; }
      banner('ddbg-shell-load', 'Duyệt Báo Giá v' + st.payload + ' đã sẵn sàng. Tải lại trang để bật phân tích.', [{ text: 'Tải lại trang', fn: function () { location.reload(); } }]);
    }, 4000);
  }
  send({ type: 'ddbg:checkUpdate' }).then(showStatus);

  // Máy phát triển: background đọc lại file trong thư mục extension, file đổi -> tự reload extension
  (function devAutoReload() {
    var isDev = false;
    try { isDev = !('update_url' in chrome.runtime.getManifest()); } catch (e) {}
    if (!isDev) return;
    var timer = null;
    function orphaned() { try { return !chrome.runtime || !chrome.runtime.id; } catch (e) { return true; } }
    function gone() {
      clearInterval(timer);
      banner('ddbg-shell-upd', '🔄 Extension Duyệt Báo Giá vừa nạp lại. Tải lại trang để dùng bản mới' +
        (/\/update\//.test(location.pathname) ? ' (bấm "Cập nhật" lưu giá trước nếu đang sửa dở)' : '') + '.',
        [{ text: 'Tải lại trang', fn: function () { location.reload(); } }]);
    }
    function check() {
      if (orphaned()) { gone(); return; }
      if (document.visibilityState !== 'visible') return;
      try { chrome.runtime.sendMessage({ type: 'ddbg:devcheck' }, function () { void chrome.runtime.lastError; if (orphaned()) gone(); }); }
      catch (e) { gone(); }
    }
    timer = setInterval(check, 2000);
    document.addEventListener('visibilitychange', check);
  })();
})();
