// Push giá tấm nhỏ vào Ghi chú — PHẦN VỎ (service worker), cài 1 lần trên mỗi máy.
// Tự cập nhật "phần ruột" (src/content.js) từ GitHub (kho công khai trithucnguyen97/duyet-bao-gia, thư mục push-ghi-chu/):
// đọc version.json, kiểm SHA-256 + chữ ký ECDSA, lưu vào chrome.storage.local và chạy trên CRM bằng chrome.userScripts.
// Máy phát triển: tự reload khi sửa phần vỏ, tự nạp bản build mới ở dist/.
var MATCHES = ['https://quanly.baobidaiduong.com/*'];
var SHELL_VERSION = chrome.runtime.getManifest().version;
var IS_DEV = !('update_url' in chrome.runtime.getManifest());

// ---------------------------------------------------------------------------
// TIN NHẮN: phần vỏ trên trang (onMessage), phần ruột (onUserScriptMessage)
// ---------------------------------------------------------------------------
function route(request, sender, sendResponse) {
    if (!request) return;
    if (request.type === 'pgc:checkUpdate') {
        checkUpdate({ throttle: !request.force }).then(sendResponse, function (e) { status().then(function (st) { st.lastError = String(e && e.message || e); sendResponse(st); }); });
        return true;
    }
    if (request.type === 'pgc:status') { status().then(sendResponse); return true; }
    if (request.type === 'pgc:openExtSettings') { chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); return; }
    if (request.type === 'pgc:devcheck') { devCheck().then(sendResponse, function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }); return true; }
}
chrome.runtime.onMessage.addListener(route);
if (chrome.runtime.onUserScriptMessage) chrome.runtime.onUserScriptMessage.addListener(route);

// ---------------------------------------------------------------------------
// CẬP NHẬT PHẦN RUỘT
// config.json: { repo: "owner/name", branch: "main", path: "dist/", token: "<token GitHub chỉ đọc>" }  (kho riêng tư, qua API)
//          hoặc { remoteBase: "https://raw.githubusercontent.com/owner/name/main/dist/" }                 (kho công khai)
// version.json: { version, files: [{ file, world, sha256 }], sig, minShell }
//   sig = ECDSA P-256/SHA-256 trên  version + "\n" + từng dòng "file:world:sha256"
// ---------------------------------------------------------------------------
var lastError = '', lastCheckAt = 0, checking = null;
function cmpVer(a, b) {
    a = String(a || '0').split('.').map(Number); b = String(b || '0').split('.').map(Number);
    for (var i = 0; i < 3; i++) { var d = (a[i] || 0) - (b[i] || 0); if (d) return d; }
    return 0;
}
async function getJSON(url, init) { var r = await fetch(url, init || { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }
async function shellConfig() { try { return await getJSON(chrome.runtime.getURL('config.json')); } catch (e) { return {}; } }
var pubKeyP = null;
function pubKey() {
    if (!pubKeyP) pubKeyP = getJSON(chrome.runtime.getURL('pubkey.json')).then(function (j) {
        return crypto.subtle.importKey('jwk', { kty: j.kty, crv: j.crv, x: j.x, y: j.y, ext: true }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    });
    pubKeyP.catch(function () { pubKeyP = null; });
    return pubKeyP;
}
function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
function b64ToBytes(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
function ghError(status) {
    if (status === 401) return 'mã truy cập GitHub sai hoặc đã hết hạn (HTTP 401)';
    if (status === 403) return 'GitHub từ chối / vượt giới hạn (HTTP 403)';
    if (status === 404) return 'không thấy bản phát hành hoặc mã truy cập không có quyền (HTTP 404)';
    return 'HTTP ' + status;
}
// Nguồn tải: dist/ trên máy (máy phát triển) và GitHub
function githubSource(cfg) {
    if (cfg.repo) {
        var base = (cfg.path || 'dist/');
        return function (f) {
            var h = { Accept: 'application/vnd.github.raw+json', 'X-GitHub-Api-Version': '2022-11-28' };
            if (cfg.token) h.Authorization = 'Bearer ' + cfg.token;
            return fetch('https://api.github.com/repos/' + cfg.repo + '/contents/' + base + f + '?ref=' + encodeURIComponent(cfg.branch || 'main') + '&t=' + Date.now(), { headers: h, cache: 'no-store' });
        };
    }
    if (cfg.remoteBase) return function (f) { return fetch(cfg.remoteBase + f + '?t=' + Date.now(), { cache: 'no-store' }); };
    return null;
}
async function sources(localOnly) {
    var out = [];
    var local = function (f) { return fetch(chrome.runtime.getURL('dist/' + f), { cache: 'no-store' }); };
    try { var lr = await local('version.json'); if (lr.ok) out.push({ v: await lr.json(), get: local, kind: 'local' }); } catch (e) {}
    if (localOnly) return out;
    var gh = githubSource(await shellConfig());
    if (gh) {
        try {
            var r = await gh('version.json');
            if (!r.ok) throw new Error(ghError(r.status));
            out.push({ v: await r.json(), get: gh, kind: 'github' });
        } catch (e) { lastError = 'Không đọc được bản phát hành trên GitHub: ' + e.message; }
    }
    return out;
}
async function download(src) {
    var v = src.v, files = [];
    for (var i = 0; i < v.files.length; i++) {
        var f = v.files[i];
        var r = await src.get(f.file);
        if (!r.ok) throw new Error('Không tải được ' + f.file + ' (' + ghError(r.status) + ')');
        var buf = await r.arrayBuffer();
        if (hex(await crypto.subtle.digest('SHA-256', buf)) !== f.sha256) throw new Error('SHA-256 của ' + f.file + ' không khớp');
        files.push({ file: f.file, world: f.world, code: new TextDecoder().decode(buf) });
    }
    var msg = new TextEncoder().encode(v.version + '\n' + v.files.map(function (f) { return f.file + ':' + f.world + ':' + f.sha256; }).join('\n'));
    var ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await pubKey(), b64ToBytes(v.sig), msg);
    if (!ok) throw new Error('Sai chữ ký — bỏ qua bản tải về');
    return files;
}
function userScriptsOk() {
    try { if (!chrome.userScripts || !chrome.userScripts.getScripts) return Promise.resolve(false); return chrome.userScripts.getScripts().then(function () { return true; }, function () { return false; }); }
    catch (e) { return Promise.resolve(false); }
}
async function registerPayload(files) {
    if (!(await userScriptsOk())) throw new Error('USERSCRIPTS_OFF');
    try { await chrome.userScripts.configureWorld({ messaging: true }); } catch (e) {}
    var old = await chrome.userScripts.getScripts();
    if (old && old.length) await chrome.userScripts.unregister({ ids: old.map(function (s) { return s.id; }) });
    await chrome.userScripts.register(files.map(function (f, i) {
        return { id: 'pgc-' + i + '-' + f.file.replace(/[^a-z0-9]/gi, '_'), matches: MATCHES, js: [{ code: f.code }], runAt: 'document_idle', world: f.world === 'MAIN' ? 'MAIN' : 'USER_SCRIPT' };
    }));
}
async function ensureRegistered() {
    var cur = (await chrome.storage.local.get('payload')).payload;
    if (!cur || !(await userScriptsOk())) return false;
    var ex = await chrome.userScripts.getScripts();
    if (!ex || ex.length !== cur.files.length || (await chrome.storage.local.get('payloadRegistered')).payloadRegistered !== cur.version) {
        await registerPayload(cur.files);
        await chrome.storage.local.set({ payloadRegistered: cur.version });
        return 'registered';
    }
    return true;
}
async function status() {
    var cur = (await chrome.storage.local.get('payload')).payload;
    var latest = (await chrome.storage.local.get('latestRemote')).latestRemote || null;
    return {
        shell: SHELL_VERSION, payload: cur ? cur.version : null, source: cur ? cur.source : null, userScripts: await userScriptsOk(),
        lastCheckAt: lastCheckAt, lastError: lastError, latest: latest && latest.version,
        shellOutdated: !!(latest && latest.minShell && cmpVer(SHELL_VERSION, latest.minShell) < 0), minShell: latest && latest.minShell
    };
}
function checkUpdate(opts) {
    opts = opts || {};
    if (checking) return checking;
    if (opts.throttle && Date.now() - lastCheckAt < 3 * 60 * 1000) return ensureRegistered().catch(function () {}).then(status);
    checking = (async function () {
        lastCheckAt = Date.now(); lastError = '';
        var cur = (await chrome.storage.local.get('payload')).payload;
        var list = await sources(opts.localOnly);
        var gh = list.find(function (s) { return s.kind === 'github'; });
        if (gh) await chrome.storage.local.set({ latestRemote: { version: gh.v.version, minShell: gh.v.minShell || null } });
        list = list.filter(function (s) { return s.v && s.v.version && s.v.sig && s.v.files && (!s.v.minShell || cmpVer(SHELL_VERSION, s.v.minShell) >= 0); });
        list.sort(function (a, b) { return cmpVer(b.v.version, a.v.version); });
        var best = list[0];
        if (best && (!cur || cmpVer(best.v.version, cur.version) > 0)) {
            var files = await download(best);
            await chrome.storage.local.set({ payload: { version: best.v.version, files: files, source: best.kind, at: Date.now() } });
            try { await registerPayload(files); await chrome.storage.local.set({ payloadRegistered: best.v.version }); }
            catch (e) { if (String(e.message) !== 'USERSCRIPTS_OFF') throw e; }
            var tabs = await chrome.tabs.query({ url: MATCHES });
            tabs.forEach(function (t) { chrome.tabs.sendMessage(t.id, { type: 'pgc:payloadUpdated', version: best.v.version }).catch(function () {}); });
        } else {
            await ensureRegistered().catch(function (e) { lastError = String(e && e.message || e); });
        }
        return status();
    })();
    checking.then(function () { checking = null; }, function (e) { lastError = String(e && e.message || e); checking = null; });
    return checking;
}
chrome.alarms.create('pgc-update', { periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'pgc-update') checkUpdate({}).catch(function () {}); });
chrome.runtime.onStartup.addListener(function () { checkUpdate({}).catch(function () {}); });

// ---------------------------------------------------------------------------
// MÁY PHÁT TRIỂN: tự reload phần vỏ khi sửa file; tự nạp bản build mới ở dist/
// ---------------------------------------------------------------------------
var DEV_FILES = ['manifest.json', 'background.js', 'shell-cs.js', 'pubkey.json', 'config.json'];
var devPending = null, devBusy = null, devLocalAt = 0;
function hashStr(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + ':' + s.length; }
async function devHash() {
    var parts = await Promise.all(DEV_FILES.map(function (f) {
        return fetch(chrome.runtime.getURL(f), { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; }, function () { return ''; });
    }));
    return hashStr(parts.join('\u0000'));
}
function devCheck() {
    if (!IS_DEV) return Promise.resolve({ ok: true, dev: false });
    if (devBusy) return devBusy;
    devBusy = (async function () {
        if (Date.now() - devLocalAt > 3000) {
            devLocalAt = Date.now();
            try {
                var lv = await getJSON(chrome.runtime.getURL('dist/version.json'));
                var cur = (await chrome.storage.local.get('payload')).payload;
                if (lv && (!cur || cmpVer(lv.version, cur.version) > 0)) await checkUpdate({ localOnly: true });
            } catch (e) {}
        }
        var base = (await chrome.storage.local.get('dev:hash'))['dev:hash'];
        var now = await devHash();
        if (!base) { await chrome.storage.local.set({ 'dev:hash': now }); return { ok: true, changed: false }; }
        if (now === base) { devPending = null; return { ok: true, changed: false }; }
        if (devPending !== now) { devPending = now; return { ok: true, changed: false, waiting: true }; }
        setTimeout(function () { chrome.runtime.reload(); }, 50);
        return { ok: true, changed: true };
    })();
    devBusy.then(function () { devBusy = null; }, function () { devBusy = null; });
    return devBusy;
}
chrome.runtime.onInstalled.addListener(function () {
    (async function () {
        await chrome.storage.local.remove('payloadRegistered');   // phần vỏ mới cài/nạp lại -> đăng ký lại phần ruột
        await checkUpdate({}).catch(function () {});
        if (IS_DEV) await chrome.storage.local.set({ 'dev:hash': await devHash() });
    })().catch(function () {});
});
chrome.runtime.onStartup.addListener(function () { if (IS_DEV) devHash().then(function (h) { chrome.storage.local.set({ 'dev:hash': h }); }).catch(function () {}); });
