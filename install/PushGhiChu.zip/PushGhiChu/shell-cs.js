// Push ghi chú — phần vỏ chạy trên CRM quanly.baobidaiduong.com (content script cố định, cài 1 lần).
// - Hỏi background kiểm tra bản mới của "phần ruột" mỗi khi mở CRM
// - Báo khi có bản mới (không tự tải lại trang: có thể đang soạn đơn dở), khi chưa bật "Cho phép tập lệnh người dùng",
//   khi phần vỏ quá cũ hoặc chưa tải được phần ruột
// - Máy phát triển (Load unpacked từ thư mục dự án): tự reload khi sửa file
(function () {
  'use strict';
  if (window.__pgcShell) return;
  window.__pgcShell = true;

  function banner(id, html, buttons) {
    var old = document.getElementById(id);
    if (old) old.remove();
    var b = document.createElement('div');
    b.id = id;
    b.style.cssText = 'position:fixed;right:16px;bottom:70px;z-index:2147483000;background:#7c2d12;color:#fff;padding:10px 14px;border-radius:10px;font:13px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);max-width:min(520px,calc(100vw - 32px))';
    b.innerHTML = html;
    (buttons || []).concat([{ text: 'Để sau', link: true, fn: function () { b.remove(); } }]).forEach(function (bt) {
      var e = document.createElement(bt.link ? 'a' : 'button');
      e.textContent = bt.text;
      if (bt.link) { e.href = '#'; e.style.cssText = 'color:#fed7aa;margin-left:10px'; }
      else e.style.cssText = 'margin-left:8px;background:#fff;color:#7c2d12;border:0;border-radius:6px;padding:4px 10px;font-weight:600;cursor:pointer';
      e.onclick = function (ev) { ev.preventDefault(); bt.fn(); };
      b.appendChild(e);
    });
    (document.body || document.documentElement).appendChild(b);
  }
  function send(msg) {
    return new Promise(function (resolve) {
      try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; resolve(r); }); } catch (e) { resolve(null); }
    });
  }
  var reloadBtn = { text: 'Tải lại trang', fn: function () { location.reload(); } };
  var saveHint = ' (bấm "Cập nhật" lưu báo giá trước nếu đang sửa dở)';

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (msg && msg.type === 'pgc:payloadUpdated')
        banner('pgc-shell-upd', '🔄 Extension Push ghi chú có bản mới <b>v' + msg.version + '</b>. Tải lại trang để dùng' + saveHint + '.', [reloadBtn]);
    });
  } catch (e) {}

  function showStatus(st) {
    if (!st) return;
    if (!st.userScripts) {
      banner('pgc-shell-perm', '⚙ Extension <b>Push giá tấm nhỏ vào Ghi chú</b> cần bật <b>"Cho phép tập lệnh người dùng"</b> (Allow User Scripts): mở trang chi tiết extension → bật công tắc đó, rồi tải lại trang.',
        [{ text: 'Mở cài đặt extension', fn: function () { send({ type: 'pgc:openExtSettings' }); } }]);
      return;
    }
    if (st.shellOutdated)
      banner('pgc-shell-old', '⬆ Phần vỏ extension Push ghi chú đã cũ (v' + st.shell + ', cần ≥ v' + st.minShell + '). Tải gói cài mới tại github.com/trithucnguyen97/duyet-bao-gia (install/PushGhiChu.zip), giải nén đè vào thư mục cũ rồi bấm tải lại (↻) ở chrome://extensions.');
    if (!st.payload) {
      banner('pgc-shell-none', '⚠ Extension Push ghi chú chưa tải được phần chính' + (st.lastError ? ': ' + String(st.lastError).replace(/</g, '&lt;') : '') + '.',
        [{ text: 'Thử lại', fn: function () { send({ type: 'pgc:checkUpdate', force: true }).then(showStatus); } }]);
      return;
    }
    // Vừa bật quyền / vừa cài: phần ruột chưa chạy trên trang đang mở -> nhắc tải lại
    setTimeout(function () {
      if (document.documentElement.getAttribute('data-pgc-payload')) return;
      banner('pgc-shell-load', 'Extension Push ghi chú v' + st.payload + ' đã sẵn sàng. Tải lại trang để bật' + saveHint + '.', [reloadBtn]);
    }, 5000);
  }
  send({ type: 'pgc:checkUpdate' }).then(showStatus);

  (function devAutoReload() {
    var isDev = false;
    try { isDev = !('update_url' in chrome.runtime.getManifest()); } catch (e) {}
    if (!isDev) return;
    var timer = null;
    function orphaned() { try { return !chrome.runtime || !chrome.runtime.id; } catch (e) { return true; } }
    function gone() { clearInterval(timer); banner('pgc-shell-upd', '🔄 Extension Push ghi chú vừa nạp lại. Tải lại trang để dùng bản mới' + saveHint + '.', [reloadBtn]); }
    function check() {
      if (orphaned()) { gone(); return; }
      if (document.visibilityState !== 'visible') return;
      try { chrome.runtime.sendMessage({ type: 'pgc:devcheck' }, function () { void chrome.runtime.lastError; if (orphaned()) gone(); }); } catch (e) { gone(); }
    }
    timer = setInterval(check, 2000);
    document.addEventListener('visibilitychange', check);
  })();
})();
