// Nhanh.vn V2 — chạy riêng trên https://banggia.baobidaiduong.com/ext-connect/done
// Đọc token riêng vừa cấp (#bgx-ext-token, chỉ có trong DOM, không có trên URL), gửi cho background, rồi xóa khỏi trang.
(function () {
  var el = document.getElementById('bgx-ext-token');
  if (!el) return;
  var token = el.getAttribute('data-token') || '', user = el.getAttribute('data-user') || '';
  el.removeAttribute('data-token');
  chrome.runtime.sendMessage({ type: 'nhx:bgToken', token: token, user: user }, function (res) {
    void chrome.runtime.lastError;
    if (res && res.ok) {
      el.remove();
      document.dispatchEvent(new CustomEvent('bgx-ext-received'));
      setTimeout(function () { try { window.close(); } catch (e) {} }, 2500);
    }
  });
})();
