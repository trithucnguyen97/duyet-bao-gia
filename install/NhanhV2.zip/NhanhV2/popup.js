// Popup: trạng thái kết nối Bảng giá (token riêng) + phiên bản; kết nối / ngắt kết nối
function send(msg) { return new Promise(function (r) { chrome.runtime.sendMessage(msg, function (res) { void chrome.runtime.lastError; r(res); }); }); }
function btn(text, ghost, fn) { var b = document.createElement('button'); b.textContent = text; if (ghost) b.className = 'ghost'; b.onclick = fn; return b; }
async function render() {
  var bg = await send({ type: 'nhx:bgStatus' }), st = await send({ type: 'nhx:status' });
  var box = document.getElementById('bg'), act = document.getElementById('actions');
  act.innerHTML = '';
  if (bg && bg.connected) {
    box.textContent = '✅ Đã kết nối Bảng giá: ' + (bg.user || '(không rõ tên)');
    act.appendChild(btn('Ngắt kết nối', true, async function () { await send({ type: 'nhx:bgLogout' }); render(); }));
  } else {
    box.textContent = bg && bg.expired ? '🔒 Kết nối Bảng giá đã bị thu hồi.' : '🔗 Chưa kết nối Bảng giá.';
    act.appendChild(btn('Kết nối Bảng giá', false, function () { send({ type: 'nhx:bgConnect' }); window.close(); }));
  }
  if (st) document.getElementById('ver').textContent = 'Phần vỏ v' + st.shell + ' · phần chính ' + (st.payload ? 'v' + st.payload : 'chưa tải') + (st.userScripts ? '' : ' · CHƯA bật "Cho phép tập lệnh người dùng"');
}
render();
